package com.ssafy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.model.service.QnaService;
import com.ssafy.model.vo.Qna;

@CrossOrigin(origins= {"*"})
@RequestMapping("/rest")
@RestController
public class QnaController {

	private QnaService qnaService;

	@Autowired
	public void setQnaService(QnaService qnaService) {
		this.qnaService = qnaService;
	}
	
	@GetMapping("/qnas")
	public ResponseEntity<List<Qna>> getQnaList(){
		List<Qna> list= qnaService.selectQnaList();
		if(list.size()==0) {
			return new ResponseEntity<List<Qna>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Qna>>(list, HttpStatus.OK);
	}
	
	@GetMapping("/qna/{number}")
	public ResponseEntity<Qna> getQna(@PathVariable int number){
		Qna q = qnaService.selectQna(number);
		if(q==null) {
			return new ResponseEntity<Qna>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Qna>(q, HttpStatus.OK);
		
	}
	
	public ResponseEntity<Qna> getQnaByTitle(@PathVariable String title){
		Qna q=qnaService.selectQnaByTitle(title);
		if(q==null) {
			return new ResponseEntity<Qna>(q, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Qna>(q, HttpStatus.OK);
	}
	
	@PostMapping("/qna")
	public ResponseEntity<Boolean> registerQna(@RequestBody Qna q){
		return qnaService.addQna(q) ? new ResponseEntity<Boolean>(true, HttpStatus.OK) : new ResponseEntity<Boolean>(false, HttpStatus.CONFLICT);
	}
	
	@PutMapping("/qna")
	public ResponseEntity<Boolean> updateQna(@RequestBody Qna q){
		return qnaService.modifyQna(q) ? new ResponseEntity<Boolean>(true, HttpStatus.OK) : new ResponseEntity<Boolean>(false, HttpStatus.NOT_FOUND);
	}
	
	public ResponseEntity<Boolean> deleteQna(@PathVariable int number){
		return qnaService.removeQna(number) ? new ResponseEntity<Boolean>(true, HttpStatus.OK) : new ResponseEntity<Boolean>(false, HttpStatus.NOT_FOUND);
	}
	
	
}
