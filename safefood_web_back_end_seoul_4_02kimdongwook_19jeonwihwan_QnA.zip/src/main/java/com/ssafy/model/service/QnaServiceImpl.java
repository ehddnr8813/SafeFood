package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dao.QnaDAO;
import com.ssafy.model.vo.Qna;

@Service
public class QnaServiceImpl implements QnaService {
	
	private QnaDAO qnaDao;

	@Autowired
	public void setQnaDao(QnaDAO qnaDao) {
		this.qnaDao = qnaDao;
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.service.QnaService#selectQna(int)
	 */
	@Override
	public Qna selectQna(int number) {
		return qnaDao.selectQna(number);
	}
	
	@Override
	public Qna selectQnaByTitle(String title) {
		return qnaDao.selectQnaByTitle(title);
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.service.QnaService#addQna(com.ssafy.model.vo.Qna)
	 */
	@Override
	public boolean addQna(Qna qna) {
		qnaDao.insertQna(qna);
		return true;
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.service.QnaService#modifyQna(com.ssafy.model.vo.Qna)
	 */
	@Override
	public boolean modifyQna(Qna qna) {
		if(selectQna(qna.getNumber())==null)return false;
		qnaDao.updateQna(qna);
		return true;
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.service.QnaService#removeQna(int)
	 */
	@Override
	public boolean removeQna(int number) {
		if(selectQna(number)==null)return false;
		qnaDao.deleteQna(number);
		return true;
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.service.QnaService#selectQnaList()
	 */
	@Override
	public List<Qna>selectQnaList(){
		return qnaDao.selectQnaList();
	}
	
}

