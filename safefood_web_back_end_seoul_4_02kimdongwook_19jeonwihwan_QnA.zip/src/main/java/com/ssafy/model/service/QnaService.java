package com.ssafy.model.service;

import java.util.List;

import com.ssafy.model.vo.Qna;

public interface QnaService {

	Qna selectQna(int number);

	boolean addQna(Qna qna);

	boolean modifyQna(Qna qna);

	boolean removeQna(int number);

	List<Qna> selectQnaList();

	Qna selectQnaByTitle(String title);

}