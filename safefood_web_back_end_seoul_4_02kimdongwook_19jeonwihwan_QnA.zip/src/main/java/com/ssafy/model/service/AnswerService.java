package com.ssafy.model.service;

import java.util.List;

import com.ssafy.model.vo.Answer;

public interface AnswerService {

	List<Answer> selectAnswerList(int number);

	boolean addAnswer(Answer answer);

}