package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dao.AnswerDAO;
import com.ssafy.model.vo.Answer;

@Service
public class AnswerServiceImpl implements AnswerService {

	private AnswerDAO answerDao;

	@Autowired
	public void setAnswerDao(AnswerDAO answerDao) { 
		this.answerDao = answerDao;
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.service.AnswerService#selectAnswerList(int)
	 */
	@Override
	public List<Answer>selectAnswerList(int number){
		return answerDao.selectAnswerList(number);
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.service.AnswerService#addAnswer(com.ssafy.model.vo.Answer)
	 */
	@Override
	public boolean addAnswer(Answer answer) {
		answerDao.insertAnswer(answer);
		return true;
	}
	
	
	
}
