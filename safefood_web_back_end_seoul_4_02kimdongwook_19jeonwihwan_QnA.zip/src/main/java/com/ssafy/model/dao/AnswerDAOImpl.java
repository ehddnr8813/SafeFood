package com.ssafy.model.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssafy.model.vo.Answer;

@Component
public class AnswerDAOImpl implements AnswerDAO {

	private SqlSession session;

	@Autowired
	public void setSession(SqlSession session) {
		this.session = session;
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.dao.AnswerDAO#insertAnswer(com.ssafy.model.vo.Answer)
	 */
	@Override
	public void insertAnswer(Answer answer) {
		session.insert("answer.insertAnswer", answer);
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.dao.AnswerDAO#selectAnswerList(int)
	 */
	@Override
	public List<Answer> selectAnswerList(int number) {
		return session.selectList("answer.selectAnswerList", number);
	}
	
}
