package com.ssafy.model.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssafy.model.vo.Answer;
import com.ssafy.model.vo.Qna;

@Component
public class QnaDAOImpl implements QnaDAO {
	
	private SqlSession session;

	@Autowired
	public void setSession(SqlSession session) {
		this.session = session;
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.dao.QnaDAO#insertQna(com.ssafy.model.vo.Qna)
	 */
	@Override
	public void insertQna(Qna qna) {
		session.insert("qna.insertQna", qna);
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.dao.QnaDAO#updateQna(com.ssafy.model.vo.Qna)
	 */
	@Override
	public void updateQna(Qna qna) {
		session.update("qna.updateQna", qna);
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.dao.QnaDAO#deleteQna(com.ssafy.model.vo.Qna)
	 */
	@Override
	public void deleteQna(int number) {
		session.delete("qna.deleteQna", number);
	}
	
	/* (non-Javadoc)
	 * @see com.ssafy.model.dao.QnaDAO#selectQnaList()
	 */
	@Override
	public List<Qna> selectQnaList(){
		return session.selectList("qna.selectQnaList");
	}
	
	@Override
	public Qna selectQna(int number) {
		return session.selectOne("qna.selectQna", number);
	}
	
	@Override
	public Qna selectQnaByTitle(String title) {
		return session.selectOne("qna.selectQnaByTitle", title);
	}
	
	
	
}
