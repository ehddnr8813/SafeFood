package com.ssafy.model.dao;

import java.util.List;

import com.ssafy.model.vo.Answer;

public interface AnswerDAO {

	void insertAnswer(Answer answer);

	List<Answer> selectAnswerList(int number);

}