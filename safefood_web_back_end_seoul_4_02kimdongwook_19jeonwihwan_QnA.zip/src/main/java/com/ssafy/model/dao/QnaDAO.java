package com.ssafy.model.dao;

import java.util.List;

import com.ssafy.model.vo.Answer;
import com.ssafy.model.vo.Qna;

public interface QnaDAO {

	void insertQna(Qna qna);

	void updateQna(Qna qna);


	List<Qna> selectQnaList();
	
	Qna selectQna(int number);

	void deleteQna(int number);

	Qna selectQnaByTitle(String title);


}