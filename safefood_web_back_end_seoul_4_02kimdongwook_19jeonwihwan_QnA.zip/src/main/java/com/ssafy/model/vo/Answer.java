package com.ssafy.model.vo;

public class Answer {

	String answer;
	int qna_number;
	
	public Answer() {
		super();
	}
	public Answer(String answer, int qna_number) {
		super();
		this.answer = answer;
		this.qna_number = qna_number;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public int getQna_number() {
		return qna_number;
	}
	public void setQna_number(int qna_number) {
		this.qna_number = qna_number;
	}
	
	@Override
	public String toString() {
		return "Answer [answer=" + answer + ", qna_number=" + qna_number + "]";
	}
	
}
