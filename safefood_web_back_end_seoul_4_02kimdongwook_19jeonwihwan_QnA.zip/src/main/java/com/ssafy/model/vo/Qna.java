package com.ssafy.model.vo;

import java.util.List;

public class Qna {

	private int number;
	private String contents;
	private String title;
	private List<String> answer;
	
	public Qna() {
	}
	public Qna(String contents, String title) {
		super();
		this.contents = contents;
		this.title = title;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<String> getAnswer() {
		return answer;
	}
	public void setAnswer(List<String> answer) {
		this.answer = answer;
	}
	
	@Override
	public String toString() {
		return "Qna [number=" + number  + ", contents=" + contents + ", title="
				+ title + ", answer=" + answer + "]";
	}
	
}
